class RP:
    def get_racecards(self, date='today'):
        return []
    def get_racecard(self, race_id):
        return {'horses': []}
